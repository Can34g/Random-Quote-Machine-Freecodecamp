import './App.css';
import { FaQuoteLeft } from "react-icons/fa";
import { FaSquareXTwitter } from "react-icons/fa6";
import { FaTumblr } from "react-icons/fa";
import { useState } from 'react';
import quotesMatrix from './data';

function App() {

  const quotes = quotesMatrix;
  const length = quotes.length;
  const [ index, setIndex ] = useState(0);
  const { quote, author } = quotes[index];

  const indexRandom = () => {
    let randomIndex = Math.floor(Math.random() * length);
    if(randomIndex === index){
      randomIndex = randomIndex - 1;
    }
    if(randomIndex < 0){
      randomIndex = 0;
    }
    setIndex(randomIndex);
  }
  return (
    <section className='section'>
      <div className='container' id="quote-box">
        <div className='quotes'>
          <FaQuoteLeft /> 
          <p id="text">{quote}</p>
          <div className='author' id="author">{`-${author}`}</div>
        </div>
        <div className='footer'>
          <div className='icons'>
          <a href="twitter.com/intent/tweet" target='_blank' id="tweet-quote"><FaSquareXTwitter /></a>
          <a href="https://tumblr.com/" target='_blank'><FaTumblr /></a>
            
          </div>
          <button className='btn' id="new-quote" onClick={indexRandom}>New quote</button>
        </div>
      </div>
    </section>
  );
}

export default App;
