 const quotes = [
      {
        "author": "Albert Einstein",
        "quote": "Imagination is more important than knowledge."
      },
      {
        "author": "Maya Angelou",
        "quote": "Try to be a rainbow in someone's cloud."
      },
      {
        "author": "Rumi",
        "quote": "The wound is the place where the Light enters you."
      },
      {
        "author": "Oscar Wilde",
        "quote": "To love oneself is the beginning of a lifelong romance."
      },
      {
        "author": "Mother Teresa",
        "quote": "Spread love everywhere you go. Let no one ever come to you without leaving happier."
      },
      {
        "author": "Helen Keller",
        "quote": "The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart."
      },
      {
        "author": "Vincent Van Gogh",
        "quote": "I am seeking, I am striving, I am in it with all my heart."
      },
      {
        "author": "Anne Frank",
        "quote": "How wonderful it is that nobody need wait a single moment before starting to improve the world."
      },
      {
        "author": "Ralph Waldo Emerson",
        "quote": "What lies behind us and what lies before us are tiny matters compared to what lies within us."
      },
      {
        "author": "Audrey Hepburn",
        "quote": "The beauty of a woman is not in a facial mode but the true beauty in a woman is reflected in her soul. It is the caring that she lovingly gives the passion that she shows. The beauty of a woman grows with the passing years."
      },
      {
        "author": "Leo Tolstoy",
        "quote": "The two most powerful warriors are patience and time."
      },
      {
        "author": "Pablo Picasso",
        "quote": "Every child is an artist. The problem is how to remain an artist once he grows up."
      },
      {
        "author": "Hermann Hesse",
        "quote": "Some of us think holding on makes us strong, but sometimes it is letting go."
      },
      {
        "author": "John Lennon",
        "quote": "Count your age by friends, not years. Count your life by smiles, not tears."
      },
      {
        "author": "Lao Tzu",
        "quote": "The journey of a thousand miles begins with one step."
      },
      {
        "author": "Kahlil Gibran",
        "quote": "Your pain is the breaking of the shell that encloses your understanding."
      }
    ];

export default quotes;